﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace IGTI.PA.ArmazenamentoDescentralizado.Controllers
{
    public class AlunoController : Controller
    {
        // GET: Cursos
        public ActionResult Index()
        {
            return View();
        }
    }
}