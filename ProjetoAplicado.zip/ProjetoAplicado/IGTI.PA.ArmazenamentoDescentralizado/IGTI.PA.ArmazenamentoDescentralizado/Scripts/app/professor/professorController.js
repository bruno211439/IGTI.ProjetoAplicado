﻿

(function () {

    'use strict';

    angular
        .module('app')
        .controller('professorController', ['$scope', '$http', 'toastr', '$localStorage', 'parseWithDate', 'serviceUpload'
            , function ($scope, $http, toastr, $localStorage, parseWithDate, serviceUpload) {

                var abi = [
                    {
                        "constant": false,
                        "inputs": [
                            {
                                "internalType": "uint256",
                                "name": "a",
                                "type": "uint256"
                            },
                            {
                                "internalType": "uint256",
                                "name": "b",
                                "type": "uint256"
                            }
                        ],
                        "name": "adicionar",
                        "outputs": [
                            {
                                "internalType": "uint256",
                                "name": "",
                                "type": "uint256"
                            }
                        ],
                        "payable": false,
                        "stateMutability": "nonpayable",
                        "type": "function"
                    },
                    {
                        "constant": true,
                        "inputs": [
                            {
                                "internalType": "uint256",
                                "name": "a",
                                "type": "uint256"
                            },
                            {
                                "internalType": "uint256",
                                "name": "b",
                                "type": "uint256"
                            }
                        ],
                        "name": "dividir",
                        "outputs": [
                            {
                                "internalType": "uint256",
                                "name": "",
                                "type": "uint256"
                            }
                        ],
                        "payable": false,
                        "stateMutability": "pure",
                        "type": "function"
                    },
                    {
                        "constant": true,
                        "inputs": [
                            {
                                "internalType": "uint256",
                                "name": "a",
                                "type": "uint256"
                            }
                        ],
                        "name": "multiplicarResultado",
                        "outputs": [
                            {
                                "internalType": "uint256",
                                "name": "",
                                "type": "uint256"
                            }
                        ],
                        "payable": false,
                        "stateMutability": "view",
                        "type": "function"
                    },
                    {
                        "constant": true,
                        "inputs": [],
                        "name": "obeterNome",
                        "outputs": [
                            {
                                "internalType": "string",
                                "name": "",
                                "type": "string"
                            }
                        ],
                        "payable": false,
                        "stateMutability": "pure",
                        "type": "function"
                    },
                    {
                        "constant": true,
                        "inputs": [],
                        "name": "obterResultado",
                        "outputs": [
                            {
                                "internalType": "uint256",
                                "name": "",
                                "type": "uint256"
                            }
                        ],
                        "payable": false,
                        "stateMutability": "view",
                        "type": "function"
                    }
                ];

                var address = "0x79c6ce913d0b8a162ef945583b03151ace219d19";

                var vm = this;
                $scope.fechamento = false;
                $scope.mensagem = "";
                $scope.nome = "";
                $scope.descricao = "";
                serviceUpload.Upload(toastr, vm, $scope, $localStorage);

                var web3js = new Web3(new Web3.providers.HttpProvider('https://ropsten.infura.io/'));

                var contract = new web3js.eth.Contract(abi, address);

                contract.methods.obeterNome().call(
                    function (error, result) {
                        console.log(result);
                    });

                contract.methods.dividir(30, 2).call(
                    function (error, result) {
                        console.log(result);
                    });

                var token = $localStorage["access_token"];

                vm.usuarioLogado = $localStorage['usuarioNome'];
                vm.tipoUsuario = $localStorage['tipoUsuario'];


                if (token == "" || token == undefined) {
                    $localStorage['access_token'] = undefined;
                    $localStorage['usuarioNome'] = undefined;
                    $localStorage['tipoUsuario'] = undefined;
                    location.href = window.urlBase + "/Home";
                }
                else if (vm.tipoUsuario == false)
                    location.href = window.urlBase + "/Aluno";


            }]);
})();