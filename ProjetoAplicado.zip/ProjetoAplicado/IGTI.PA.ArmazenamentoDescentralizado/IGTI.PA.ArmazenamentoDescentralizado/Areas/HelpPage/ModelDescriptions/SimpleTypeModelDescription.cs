namespace IGTI.PA.ArmazenamentoDescentralizado.Areas.HelpPage.ModelDescriptions
{
    public class SimpleTypeModelDescription : ModelDescription
    {
    }
}