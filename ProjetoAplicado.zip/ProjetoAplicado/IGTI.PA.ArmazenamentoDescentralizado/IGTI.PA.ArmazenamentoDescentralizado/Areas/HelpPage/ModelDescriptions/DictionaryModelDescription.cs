namespace IGTI.PA.ArmazenamentoDescentralizado.Areas.HelpPage.ModelDescriptions
{
    public class DictionaryModelDescription : KeyValuePairModelDescription
    {
    }
}