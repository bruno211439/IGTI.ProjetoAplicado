﻿using IGTI.PA.Infrastructure;
using IGTI.PA.Models;
using System;
using Newtonsoft.Json.Linq;
using IGTI.PA.Interface;
using IGTI.PA.Core;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace IGTI.PA.Service
{
    public class AlunoService
    {
        private ProjetoAplicadoDbContext db = new ProjetoAplicadoDbContext();

        public dynamic Get()
        {
            try
            {
                return db.Curso.ToList();
                
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

    }
}
