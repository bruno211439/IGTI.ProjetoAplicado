﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace IGTI.PA.Models.Entity
{
    [Table("AlunoCurso")]
    public class AlunoCurso : BaseEntity
    {
        public int UsuarioId { get; set; }
        [ForeignKey("UsuarioId")]
        public virtual Usuario Usuario { get; set; }

        public int CursoId { get; set; }
        [ForeignKey("CursoId")]
        public virtual Curso Curso { get; set; }
    }
}
