namespace IGTI.PA.ArmazenamentoDescentralizado.Api.Areas.HelpPage.ModelDescriptions
{
    public class SimpleTypeModelDescription : ModelDescription
    {
    }
}