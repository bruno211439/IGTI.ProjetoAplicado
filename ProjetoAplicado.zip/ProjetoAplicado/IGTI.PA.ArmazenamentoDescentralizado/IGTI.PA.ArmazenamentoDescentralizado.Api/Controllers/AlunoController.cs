﻿using IGTI.PA.Service;
using System;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace IGTI.PA.ArmazenamentoDescentralizado.Api.Controllers
{
    [Authorize]
    [RoutePrefix("api/Aluno")]
    public class AlunoController : ApiController
    {
        private readonly AlunoService alunoService = new AlunoService();


        [HttpGet]
        [ActionName("CarrgarCurso")]
        public dynamic CarrgarCurso()
        {
            try
            {
                var result = alunoService.Get();
                return ModelState.IsValid ? result : Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, ModelState);

            }
            catch (Exception e)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, e.InnerException.InnerException.Message);
            }
        }
    }
}
